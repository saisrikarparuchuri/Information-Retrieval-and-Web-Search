from __future__ import division
import string
import math
from bs4 import BeautifulSoup
import re
import nltk
import os
from collections import Counter
import operator
import time
from nltk.tokenize import sent_tokenize, word_tokenize 
from Assignment import count_words
tokenize = lambda doc: doc.lower().split(" ")
special_characters=["+","(",".",")",",","-","#","$","[","]","{","}",">","<","?","!","%","''","&","@",";",":","'"]
def mapping(list):												 
															
	count=Counter(list)
	
	
	for key,value in count.most_common():
		freq_list[key]=value
	abc=[]
	abc.append(filename)
	abc.append(freq_list)
	map_list.append(abc)
	abc=[]
	
summ=0
token_list=[]
map_list=[]
freq_list={}										
textfile=open('new 1','r')


for line in textfile:
	list_of_stopword = [i.replace('\n','') for i in textfile]			

path="c:/users/saisrikar/desktop/cranfieldDocs"
allfile=os.listdir(path)
length= len(allfile)
for filename in allfile:
	#print ('***************************' +filename +'************************************')
	file=open(os.path.join(path,filename),'r')
	for line in file:
		Soup=BeautifulSoup(line, "lxml")					
		text = Soup.getText()
		tokens=re.split(r'([\d.]+|\W+)',text)
		my_list = [str(tokens[x]) for x in range(len(tokens))]				
		if len(my_list)>1:
			for i in my_list:
				if i.isalnum() or i.isalpha():			
					if i not in list_of_stopword and i !='a':
						token_list.append(i)
					else:
						tokens.remove(i)
	new_list=token_list
		
	
	
	mapping(new_list )
					
	token_list=[]
	freq_list={}												
			
for i in map_list:								
	print ('**************')
	print ('				')
	print (i)
single_keylist=[]
double_keylist=[]
third_keylist=[]	
print ('	')
print ('	')
print ('Enter the keyword(s)')			
keyword=list(map(str,input().strip().split(" ")))				
print ('the input is ', keyword)
if len(keyword)<=1:
	for i in range(length):
		all_key=map_list[i][1]
		#print (all_key)
		for eachvalue in keyword:										#
			if eachvalue in all_key:
				temp=[]
				temp.append(map_list[i][0])
				temp.append(map_list[i][1][eachvalue])
				single_keylist.append(temp)
				temp=[]
	single_keylist=sorted(single_keylist, key=operator.itemgetter(1), reverse=True)
	single_keylist=single_keylist[:10]
	for x,y in single_keylist:
		print (x,y)

elif (len(keyword)==2):
	for i in range(length):
		all_key=map_list[i][1]
		#print ('	')
		#print(all_key)
		for n in keyword:
			if n in all_key:
				summ=summ+map_list[i][1][n] 		
		temp=[]		
		temp.append(map_list[i][0])
		temp.append(summ)
		double_keylist.append(temp)
		summ=0
		temp=[]
	double_keylist=sorted(double_keylist, key=operator.itemgetter(1), reverse=True)
	double_keylist=double_keylist[:10]
	for x,y in double_keylist:
		print (x,y)
		
elif(len(keyword)==3):
	for i in range(length):
		all_key=map_list[i][1]
		#print (all_key)
		#print ('	')
		#print all_key
		for n in keyword:
			if n in all_key:
				summ=summ+map_list[i][1][n]
		temp=[]		
		temp.append(map_list[i][0])
		temp.append(summ)
		third_keylist.append(temp)
		summ=0		
		temp=[]
	third_keylist=sorted(third_keylist, key=operator.itemgetter(1), reverse=True)
	third_keylist=third_keylist[:10]
	for x,y in third_keylist:
		print (x,y)
		
	
	
def term_frequency(term, tokenized_document):
    return tokenized_document.count(term)

def sublinear_term_frequency(term, tokenized_document):
    count = tokenized_document.count(term)
    if count == 0:
        return 0
    return 1 + math.log(count)
	
def augmented_term_frequency(term, tokenized_document):
    max_count = max([term_frequency(t, tokenized_document) for t in tokenized_document])
    return (0.5 + ((0.5 * term_frequency(term, tokenized_document))/max_count))
	
def inverse_document_frequencies(tokenized_documents):
    idf_values = {}
    all_tokens_set = set([item for sublist in tokenized_documents for item in sublist])
    for tkn in all_tokens_set:
        contains_token = map(lambda doc: tkn in doc, tokenized_documents)
        idf_values[tkn] = 1 + math.log(len(tokenized_documents)/(sum(contains_token)))
    return idf_values

def tfidf(documents):
    tokenized_documents = [tokenize(d) for d in documents]
    idf = inverse_document_frequencies(tokenized_documents)
    tfidf_documents = []
    for document in tokenized_documents:
        doc_tfidf = []
        for term in idf.keys():
            tf = sublinear_term_frequency(term, document)
            doc_tfidf.append(tf * idf[term])
        tfidf_documents.append(doc_tfidf)
    return tfidf_documents
	
#in Scikit-Learn
from sklearn.feature_extraction.text import TfidfVectorizer

sklearn_tfidf = TfidfVectorizer(norm='l2',min_df=0, use_idf=True, smooth_idf=False, sublinear_tf=True, tokenizer=tokenize)
sklearn_representation = sklearn_tfidf.fit_transform(new_list)

def cosine_similarity(vector1, vector2):
    dot_product = sum(p*q for p,q in zip(vector1, vector2))
    magnitude = math.sqrt(sum([val**2 for val in vector1])) * math.sqrt(sum([val**2 for val in vector2]))
    if not magnitude:
        return 0
    return dot_product/magnitude
tfidf_representation = tfidf(new_list)
our_tfidf_comparisons = []
for count_0, doc_0 in enumerate(tfidf_representation):
    for count_1, doc_1 in enumerate(tfidf_representation):
        our_tfidf_comparisons.append((cosine_similarity(keyword, new_list), count_0, count_1))

skl_tfidf_comparisons = []
for count_0, doc_0 in enumerate(sklearn_representation.toarray()):
    for count_1, doc_1 in enumerate(sklearn_representation.toarray()):
        skl_tfidf_comparisons.append((cosine_similarity(keyword, new_list), count_0, count_1))

for x in zip(sorted(our_tfidf_comparisons, reverse = True), sorted(skl_tfidf_comparisons, reverse = True)):
    print (x)
	





	








