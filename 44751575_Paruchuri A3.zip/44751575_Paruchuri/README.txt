System Requirements:


Operating System		: Windows 8 and later version of windows

Libraries 			: Natural Language Toolkit, Beautifulsoap, os, 				  Scikit

Environment			: Python  3.5 32-bit

Language			: Python 3

Placement of input files: Cranfield Docs folder that is stored in desktop
