from nltk.tokenize import sent_tokenize, word_tokenize
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
from collections import Counter
import os
special_characters=["+","(",".",")",",","-"]

path="c:/users/saisrikar/desktop/cranfieldDocs"
blist=[]
for filename in os.listdir(path):
    doc=open(os.path.join(path, filename),"r")
    soup = BeautifulSoup(doc,"lxml")
    text = soup.get_text()
    tokens=word_tokenize(text.lower())
    for s in tokens:
        if s not in special_characters:
            blist.append(s)
print("The total number of words before stopwords",len(blist))
unique_words0=set(blist)
print("Unique words before removing stopwords",len(unique_words0))
counts0=Counter(blist)
print("Freq of all words before removing stopwords",counts0)
print("Frequency top 50 words before removing stopwords")
for word, frequency in counts0.most_common(50):
    print(u"{}:{}".format(word, frequency))
#stopwords
stopwords = open("new 1","r").read()
alist=[]
print("Tokens after removing stopwords")
for w in blist:
    if w not in stopwords:
        alist.append(w)
unique_words=set(alist)
counts = Counter(alist)
print("Frequency of words after removing stopwords",counts)
print("Frequency top 50 words after removing stopwords")
for word, frequency in counts.most_common(50):
    print(u"{}:{}".format(word, frequency))
print("After removing stopwords Total no of words",len(alist))
print("After removing stopwords unique words",len(unique_words))


        

        






