from nltk.tokenize import sent_tokenize, word_tokenize
from bs4 import BeautifulSoup
from nltk.corpus import stopwords
from collections import Counter
from nltk import FreqDist
import os
import csv
special_characters=["+","(",".",")",",","-","#","$","[","]","{","}",">","<","?","!","%","''","&","@",";",":","'"]
path="c:/users/saisrikar/desktop/cranfieldDocs"
blist=[]
for filename in os.listdir(path):
    doc=open(os.path.join(path,filename),"r",encoding='utf-8',errors='ignore')
    #print(doc)
    soup = BeautifulSoup(doc,"lxml")
    text = soup.get_text()
    tokens=word_tokenize(text.lower())
    for s in tokens:
        if s not in special_characters:
            blist.append(s)
#stopwords
stopwords = open("new 1","r").read()
alist=[]
print("Tokens after removing stopwords, sgml tags")
for w in blist:
    if w not in stopwords:
        alist.append(w)
def count_words(alist):
	d={}
	for word in alist:
		d[word]=d.get(word,0)+1
	for w, c in d.items():
		print("%s: %d times" % (w,c))
print('list of d')
print(count_words(alist))
frequency=Counter(alist)
for word, frequency in frequency.most_common(10):
    print(u"{}:{}".format(word, frequency))
for word, frequency in frequency.most_common[-10: ]:
	print (u"{}:{}".format(word, frquency))
name=input("Enter the Keyword: ")
print(name)